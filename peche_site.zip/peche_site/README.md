# 🎣 PêcheMR – Site de Pêche en Mauritanie

Site web Flask pour la pêche en Mauritanie avec formulaire de réservation.

## Structure du projet

```
peche_site/
├── app.py              ← Backend Python Flask
├── requirements.txt    ← Dépendances Python
├── render.yaml         ← Config déploiement Render
└── templates/
    └── index.html      ← Site web complet
```

---

## 🚀 Déploiement GRATUIT sur Render

### Étape 1 – Mettre le code sur GitHub

1. Créez un compte sur https://github.com
2. Cliquez "New repository" → nommez-le `peche-mr`
3. Uploadez tous les fichiers du projet

Ou via terminal :
```bash
git init
git add .
git commit -m "Premier déploiement PêcheMR"
git branch -M main
git remote add origin https://github.com/VOTRE_NOM/peche-mr.git
git push -u origin main
```

### Étape 2 – Déployer sur Render

1. Allez sur https://render.com → créez un compte gratuit
2. Cliquez **"New +"** → **"Web Service"**
3. Connectez votre dépôt GitHub `peche-mr`
4. Render détecte automatiquement `render.yaml`
5. Cliquez **"Create Web Service"**
6. Attendez 2–3 minutes → votre site est en ligne !

Votre URL sera : `https://peche-mr.onrender.com`

---

## 🖥️ Tester localement

```bash
pip install -r requirements.txt
python app.py
```
Ouvrez http://localhost:5000

---

## 📋 API

| Méthode | URL | Description |
|---------|-----|-------------|
| GET | / | Page principale |
| POST | /api/reserver | Envoyer une réservation |
| GET | /api/reservations | Voir toutes les réservations |

---

## 📝 Notes

- Les réservations sont sauvegardées dans `reservations.json`
- Pour un vrai projet, remplacez par PostgreSQL (gratuit sur Render aussi)
